load("voice_list.js");

function execute(text, voice) {
    let voiceInfo = voices.find(function (e) {
        return e.id == voice;
    });
    let lang = "vi";
    if (voiceInfo) {
        lang = voiceInfo.language;
    }

    // Trích xuất SNlM0e từ trang web (nếu cần)
    let SNlM0e = extractSNlM0e();
    if (!SNlM0e) {
        console.error("Không thể trích xuất SNlM0e.");
        return null;
    }

    // Tạo payload và gửi request
    let payload = getPayloadData(text, lang);
    let response = fetch("https://gemini.google.com/_/BardChatUi/data/batchexecute", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Cookie": "", // Thêm cookie nếu cần
        },
        body: `f.req=${encodeURIComponent(payload)}&at=${SNlM0e}`
    });

    if (response.ok) {
        let data = response.text().replace(/^\)\]\}'/, '').trim(); // Loại bỏ phần )]}' ở đầu response
        try {
            const jsonArray = JSON.parse(data);
            const contentArray = JSON.parse(jsonArray[0][2]);
            return Response.success(contentArray[0]); // Trả về kết quả
        } catch (e) {
            console.error("Lỗi khi phân tích response:", e);
            return null;
        }
    } else {
        console.error("Lỗi request:", response.status, response.statusText);
        return null;
    }
}

function extractSNlM0e() {
    let response = fetch("https://gemini.google.com");
    if (response.ok) {
        let match = /SNlM0e":"(.*?)"/.exec(response.text());
        if (match) return match[1];
    }
    return null;
}

function getPayloadData(text, lang) {
    const data = ["XqA3Ic", JSON.stringify([null, text, lang, null, 2]), null, "generic"];
    return JSON.stringify([[data]]);
}